#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs, os
import time


def box():
	dialog = xbmcgui.Dialog()
	dialog.ok("WELCOME TO FIRST RUN", "The wizard on the next page will guide you through the setup. !!!NOTE!!! If your remote doesn't work then reboot.")
	xbmc.executebuiltin('Addon.OpenSettings(script.module.authorize)') 
	
	
	
def get_flash():
	src = '/flash/storage/'
	dst = '/storage/'
	from distutils.dir_util import copy_tree 

	if not os.path.exists (src):
		box()

	else:
		copy_tree(src,dst)
		box()
		

get_flash()




# #!/usr/bin/python
# # -*- coding: utf-8 -*-
# import xbmc, xbmcgui, xbmcvfs, os
# import time


# time.sleep(5)
# choice = xbmcgui.Dialog().yesno('WELCOME TO FIRST RUN', 'Would you like to restore your personal settings from existing backup or set up as a new box? Any current error message are because your box is not connected to WiFi. Click the back key to clear any error messages', nolabel='RESTORE',yeslabel='NEW', autoclose=int(20000))
# if choice == 0:
	# xbmc.executebuiltin('Addon.OpenSettings(plugin.program.backup)') 
	# #xbmc.executebuiltin('Addon.OpenSettings(plugin.program.backup)') 
	# time.sleep(1)
	# xbmc.executebuiltin('Action(Right)') 
	# xbmc.executebuiltin('Action(Right)') 
	# time.sleep(50)
	# xbmc.executebuiltin('Action(Select)')  
	# time.sleep(10)
	# xbmc.executebuiltin('RunAddon(plugin.program.backup)') 
	# xbmc.executebuiltin('Dialog.Close(busydialog)')




# elif choice == 1: 

	
	# #dialog.ok("WELCOME TO FIRST RUN", "On the next screen you can setup WiFi then all your services. NOTE!!! The setup addon called SYNC Can be found under the puzzle piece then programs") 
	# xbmc.executebuiltin('RunAddon(script.module.authorize)')













# time.sleep(10)
# xbmc.executebuiltin('Addon.OpenSettings(plugin.program.backup)') 
# time.sleep(1)
# xbmc.executebuiltin('Action(Right)') 
# xbmc.executebuiltin('Action(Right)') 
# time.sleep(50)
# xbmc.executebuiltin('Action(Select)')  
# time.sleep(10)
# xbmc.executebuiltin('RunAddon(plugin.program.backup)') 
# xbmc.executebuiltin('Dialog.Close(busydialog)')

